const Header = () => {
  return <>
  <div>
    <h1>학생성적 관리</h1>
  </div>
  </>
}
export default Header;